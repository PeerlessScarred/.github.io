# index.html
This is an index.html lab
In this lab, I was tasked with creating an html file that had a brief introduction about myself an was styled using a minimum of three colors. I ran the file multiple times to debug and fix the issues. Over the course of this file creation, I had to edit the code several times to fix the color issues. 
